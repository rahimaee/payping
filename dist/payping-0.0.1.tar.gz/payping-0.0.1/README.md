# payping

payping is a Python library for using  web services (www.payping.ir)

 [documentation](https://docs.payping.ir/)

پی پینگ یک کتابخانه پایتون برای استفاده از خدمات پرداخت وب سروریس پی پینگ دات ایر است



[مستند ها سایت](https://docs.payping.ir/)

## Installation

Use the package manager [pip](https://pypi.org/project/payping/) to install payping.

```bash
pip install payping
```

## Usage

دریافت توکن

GET Token

```python



```





## License

[MIT](https://github.com/rahimaee/smsir/blob/main/LICENSE)